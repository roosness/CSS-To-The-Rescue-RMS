# CSS-To-The-Rescue-RMS

live link : http://roosness.github.io/CSS-To-The-Rescue-RMS/

Aangepast op feedback:

- ampersand toegevoegd (lijn 18)
- max 3 selectoren 
- font-size: 1em weggehaald


nieuwe technieken: 

- Intrinsic sizing  (in de photoalbums, te vinden op 561)
- vertical centering (o a in de foto filters, te vinden op 365)
- de-emphasizing (in de foto filters, te vinden op 365)
- styling by sibling count (oa in de foto filters, 422, en in de foto albums, 668)
- target selector (in de foto filters, 365)

Week 3 nieuwe technieken

- loading spinner
- transitions op hover en focus
- cursor
- extending the clickable area
- custom checkboxes
- pseudo random background